# Backend

Generated stub for uber-eats-clone. Run with `node server/index.js` after wiring an Express server.