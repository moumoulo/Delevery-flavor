```js
// server/api.js
// Express-style handlers with in‑memory mock data

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const router = express.Router();

// ----- In‑memory data stores -----

const users = [
  // Example user (hashed password)
  {
    id: uuidv4(),
    email: 'alice@example.com',
    password: bcrypt.hashSync('password123', 10),
    name: 'Alice',
    phone: '+1234567890',
    address: '123 Main St, Cityville',
  },
];

const restaurants = [
  {
    id: uuidv4(),
    name: 'Sushi World',
    address: '456 Sushi St, Cityville',
    cuisine: 'Japanese',
    rating: 4.5,
    menu: [
      { id: uuidv4(), name: 'California Roll', price: 8.99 },
      { id: uuidv4(), name: 'Spicy Tuna Roll', price: 9.99 },
    ],
  },
  {
    id: uuidv4(),
    name: 'Pasta Place',
    address: '789 Pasta Ave, Cityville',
    cuisine: 'Italian',
    rating: 4.0,
    menu: [
      { id: uuidv4(), name: 'Spaghetti Carbonara', price: 12.99 },
      { id: uuidv4(), name: 'Fettuccine Alfredo', price: 13.99 },
    ],
  },
];

const orders = [];

// ----- Auth utilities -----

const JWT_SECRET = 'replace-with-a-secure-random-secret';

const generateToken = (user) => {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, {
    expiresIn: '1h',
  });
};

const verifyToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
};

// Middleware: Authentication
const authRequired = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid token' });
  }
  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  req.user = payload; // attach user payload to request
  next();
};

// ----- Route Handlers -----

// 1. GET /api/restaurants – list with optional filters
router.get('/api/restaurants', (req, res) => {
  let result = [...restaurants];
  const { cuisine, minRating, maxRating, search } = req.query;

  if (cuisine) {
    result = result.filter((r) => r.cuisine.toLowerCase() === cuisine.toLowerCase());
  }
  if (minRating) {
    result = result.filter((r) => r.rating >= Number(minRating));
  }
  if (maxRating) {
    result = result.filter((r) => r.rating <= Number(maxRating));
  }
  if (search) {
    const q = search.toLowerCase();
    result = result.filter(
      (r) =>
        r.name.toLowerCase().includes(q) ||
        r.address.toLowerCase().includes(q) ||
        r.cuisine.toLowerCase().includes(q)
    );
  }

  res.json(result);
});

// 2. GET /api/restaurants/:id – details
router.get('/api/restaurants/:id', (req, res) => {
  const restaurant = restaurants.find((r) => r.id === req.params.id);
  if (!restaurant) return res.status(404).json({ error: 'Restaurant not found' });
  res.json(restaurant);
});

// 3. POST /api/orders – place new order (requires auth)
router.post('/api/orders', authRequired, (req, res) => {
  const { restaurantId, items, deliveryAddress, paymentMethod } = req.body;

  if (!restaurantId || !items || !deliveryAddress || !paymentMethod) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const restaurant = restaurants.find((r) => r.id === restaurantId);
  if (!restaurant) return res.status(404).json({ error: 'Restaurant not found' });

  // Calculate total
  let total = 0;
  const orderItems = items.map((item) => {
    const menuItem = restaurant.menu.find((m) => m.id === item.id);
    if (!menuItem) {
      throw new Error(`Menu item ${item.id} not found`);
    }
    const lineTotal = menuItem.price * (item.quantity || 1);
    total += lineTotal;
    return { ...menuItem, quantity: item.quantity || 1, lineTotal };
  });

  const order = {
    id: uuidv4(),
    userId: req.user.id,
    restaurantId,
    items: orderItems,
    total,
    status: 'Pending',
    deliveryAddress,
    paymentMethod,
    createdAt: new Date().toISOString(),
  };

  orders.push(order);
  res.status(201).json(order);
});

// 4. GET /api/orders/:id – details (requires auth)
router.get('/api/orders/:id', authRequired, (req, res) => {
  const order = orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  // Simple ownership check
  if (order.userId !== req.user.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  res.json(order);
});

// 5. GET /api/orders/:id/track – mock tracking (requires auth)
router.get('/api/orders/:id/track', authRequired, (req, res) => {
  const order = orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  if (order.userId !== req.user.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Simulate simple status timeline
  const tracking = [
    { timestamp: new Date(order.createdAt).toISOString(), status: 'Order received' },
    {
      timestamp: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      status: 'Preparing food',
    },
    {
