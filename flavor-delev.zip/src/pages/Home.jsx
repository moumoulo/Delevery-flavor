import React from 'react';

export default function Home() {
  return (
    <div className="font-sans min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-green-500 text-white py-4 shadow-md">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
          <h1 className="text-2xl font-bold">Find Your Meal</h1>
          <input
            type="text"
            placeholder="Search restaurants"
            className="mt-2 md:mt-0 bg-white bg-opacity-20 text-white rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-white"
          />
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto py-6 px-4">
        {/* Featured Restaurants */}
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Featured Restaurants</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow duration-200">
                <img
                  src={`https://picsum.photos/seed/${index}/400/250`}
                  alt="Restaurant"
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <div className="p-4">
                  <h3 className="text-lg font-medium mb-1">Restaurant {index + 1}</h3>
                  <p className="text-sm text-gray-600">Lorem ipsum dolor sit amet.</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Current Promotions */}
        <section>
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Current Promotions</h2>
          <div className="space-y-4">
            {['Free dessert with main course', '20% off on weekends', 'Early bird specials'].map((promo, idx) => (
              <div key={idx} className="flex items-center bg-amber-100 rounded-lg p-3">
                <svg
                  className="w-6 h-6 text-amber-600 mr-3"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h1l1-4h16l1 4h1" />
                </svg>
                <span className="text-sm text-gray-700">{promo}</span>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-green-500 text-white py-4 shadow-md">
        <div className="container mx-auto text-center py-2">
          © 2026 Find Your Meal. All rights reserved.
        </div>
      </footer>
    </div>
  );
}