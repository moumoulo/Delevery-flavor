export default function OrderCart() {
  return (
    <div className="min-h-screen bg-gray-100 font-roboto">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Your Shopping Cart</h1>
        <div className="bg-white rounded-lg shadow-md p-6 mb-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Order Summary</h2>
            <button className="text-green-600 hover:text-green-800 font-medium">Clear Cart</button>
          </div>
          <div className="space-y-4">
            {/* Cart Item 1 */}
            <div className="flex items-center border-b border-gray-200 pb-4">
              <img src="https://via.placeholder.com/100" alt="Product" className="w-20 h-20 object-cover rounded-md" />
              <div className="flex-1 ml-4">
                <h3 className="text-lg font-medium text-gray-800">Premium Wireless Headphones</h3>
                <p className="text-gray-600">$199.99</p>
                <div className="flex items-center mt-2">
                  <button className="text-gray-500 hover:text-gray-700">-</button>
                  <span className="mx-2 text-gray-700">1</span>
                  <button className="text-gray-500 hover:text-gray-700">+</button>
                </div>
              </div>
              <button className="text-red-500 hover:text-red-700 ml-4">Remove</button>
            </div>
            {/* Cart Item 2 */}
            <div className="flex items-center border-b border-gray-200 pb-4">
              <img src="https://via.placeholder.com/100" alt="Product" className="w-20 h-20 object-cover rounded-md" />
              <div className="flex-1 ml-4">
                <h3 className="text-lg font-medium text-gray-800">Smart Watch</h3>
                <p className="text-gray-600">$149.99</p>
                <div className="flex items-center mt-2">
                  <button className="text-gray-500 hover:text-gray-700">-</button>
                  <span className="mx-2 text-gray-700">2</span>
                  <button className="text-gray-500 hover:text-gray-700">+</button>
                </div>
              </div>
              <button className="text-red-500 hover:text-red-700 ml-4">Remove</button>
            </div>
          </div>
          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Subtotal</span>
              <span className="text-gray-800">$549.97</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Shipping</span>
              <span className="text-gray-800">$9.99</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Tax</span>
              <span className="text-gray-800">$45.00</span>
            </div>
            <div className="flex justify-between items-center font-bold text-lg mt-4">
              <span>Total</span>
              <span>$604.96</span>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6 mb-4">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Apply Coupon</h2>
          <div className="flex">
            <input
              type="text"
              placeholder="Enter coupon code"
              className="flex-1 border border-gray-300 rounded-l-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-r-md">Apply</button>
          </div>
        </div>
        <div className="flex justify-end">
          <button className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-md">Proceed to Checkout</button>
        </div>
      </div>
    </div>
  );
}