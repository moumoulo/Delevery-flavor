```jsx
import React, { useState } from 'react';

export default function HelpSupportPage() {
  const [faqActive, setFaqActive] = useState(null);

  const toggleFaq = (index) => {
    setFaqActive(faqActive === index ? null : index);
  };

  return (
    <div style={{ fontFamily: 'Roboto, sans-serif' }} className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <header className="text-center mb-12">
        <h1 className="text-4xl