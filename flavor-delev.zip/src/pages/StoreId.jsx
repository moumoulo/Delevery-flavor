export default function RestaurantDetails() {
  return (
    <div className="min-h-screen bg-gray-100 font-roboto">
      <header className="bg-[#4CAF50] text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Restaurant Name</h1>
          <div className="flex items-center space-x-4">
            <span className="text-lg">⭐ 4.5</span>
            <button className="bg-white text-[#4CAF50] px-4 py-2 rounded-full font-semibold hover:bg-gray-100 transition duration-300">
              Order Now
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4">
        <section className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Menu</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="border rounded-lg p-4 hover:shadow-lg transition duration-300">
                <h3 className="font-semibold">Dish Name {item}</h3>
                <p className="text-gray-600">Description of the dish goes here.</p>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-[#4CAF50] font-bold">$12.99</span>
                  <button className="bg-[#4CAF50] text-white px-3 py-1 rounded-full text-sm hover:bg-green-700 transition duration-300">
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Reviews</h2>
          <div className="space-y-4">
            {[1, 2, 3].map((review) => (
              <div key={review} className="border-b pb-4 last:border-b-0">
                <div className="flex items-center mb-2">
                  <span className="text-[#4CAF50] mr-2">⭐⭐⭐⭐⭐</span>
                  <span className="font-semibold">Reviewer Name {review}</span>
                </div>
                <p className="text-gray-700">This is a sample review text for the restaurant. The food was delicious and the service was excellent.</p>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Order Options</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border rounded-lg p-4 hover:shadow-lg transition duration-300">
              <h3 className="font-semibold">Delivery</h3>
              <p className="text-gray-600">Order food for delivery to your doorstep.</p>
              <button className="mt-2 bg-[#4CAF50] text-white px-4 py-2 rounded-full font-semibold hover:bg-green-700 transition duration-300">
                Order Delivery
              </button>
            </div>
            <div className="border rounded-lg p-4 hover:shadow-lg transition duration-300">
              <h3 className="font-semibold">Pickup</h3>
              <p className="text-gray-600">Pick up your order from the restaurant.</p>
              <button className="mt-2 bg-[#4CAF50] text-white px-4 py-2 rounded-full font-semibold hover:bg-green-700 transition duration-300">
                Order Pickup
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#4CAF50] text-white p-4 mt-6">
        <div className="container mx-auto text-center">
          <p>&copy; 2023 Restaurant Name. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}