```jsx
import React, { useState } from "react";

export default function AccountPage() {
  const [activeTab, setActiveTab] = useState("profile");

  const tabs = [
    { id: "profile", label: "Profile" },
    { id: "payment", label: "Payment Methods" },
    { id: "orders", label: "Order History" },
  ];

  return (
    <div className="min-h-screen bg-gray-100 font-roboto">
      <header className="bg-[#4CAF50] text-white py-4">
        <h1 className="text-3xl font-semibold text-center">Account</h1>
      </header>

      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-4 -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-4 font-medium text-sm rounded-t-lg border-t-2 ${
                  activeTab === tab.id
                    ? "border-[#4CAF50] text-[#4CAF50]"
                    : "border-transparent text-gray-700 hover:text-gray-800 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {activeTab === "profile" && (
          <section className="bg-white shadow rounded-lg p-6">
            <h2 className="text-2xl font-medium mb-4 text-[#4CAF50]">